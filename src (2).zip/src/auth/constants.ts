export const jwtConstants = {
    secret: 'qwjbkdjdwbjdbhjsdbhjdfbj'
}