// documents/documents.controller.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { DocumentsController } from '../../documents/documents.controller';
import { DocumentService } from '../../documents/documents.service';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Document } from '../../documents/entity/documents.entity';

describe('DocumentsController', () => {
  let controller: DocumentsController;
  let service: DocumentService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [DocumentsController],
      providers: [
        DocumentService,
        {
          provide: getRepositoryToken(Document),
          useValue: {
            find: jest.fn().mockResolvedValue([]),
            findOne: jest.fn(),
            save: jest.fn(),
          },
        },
      ],
    }).compile();

    controller = module.get<DocumentsController>(DocumentsController);
    service = module.get<DocumentService>(DocumentService);
  });

  describe('upload', () => {
    it('should return created document', async () => {
      const mockFile = { originalname: 'test.pdf', buffer: Buffer.from('test') };
      jest.spyOn(service, 'create').mockResolvedValue({} as Document);
      expect(await controller.uploadFile(mockFile)).toBeDefined();
    });
  });
});